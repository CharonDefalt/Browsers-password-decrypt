---
name: I didn't find documentation on how to...
about: Tell us what you are missing in the docs or feel unclear about

---

<!--- 
This project is aimed at intermediate users and has minimal documentation so things can be confusing for anyone less versed on any of the involved concepts.

We'd still like to make this little tool useful to you so feel free to ask anything you feel is unclear.
It will help us improve and potentially help other users like yourself.
--->

**Can you clarify...**
(Elaborate your question here)
